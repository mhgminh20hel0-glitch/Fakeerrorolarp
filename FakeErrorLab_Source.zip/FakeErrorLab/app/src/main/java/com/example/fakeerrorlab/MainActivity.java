package com.example.fakeerrorlab;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView countdown, preview, status;
    private Spinner typeSpinner, colorSpinner, fontSpinner, lengthSpinner;
    private SeekBar timerBar;
    private CountDownTimer timer;
    private int seconds = 10;
    private boolean dialogShown = false;
    private final String[] types = {
        "Ứng dụng liên tục dừng", "Ứng dụng không phản hồi", "Đã xảy ra lỗi", "Không thể tải nội dung", "Lỗi kết nối", "Lỗi giả lập tùy chỉnh"
    };
    private final String[] colors = {"Trắng hệ thống", "Tối", "Xanh lá", "Vàng", "Đỏ", "Xanh dương"};
    private final String[] fonts = {"Mặc định", "Sans-serif", "Serif", "Monospace"};
    private final String[] lengths = {"Ngắn", "Vừa", "Dài"};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi(); updatePreview(); startTimer(seconds);
    }

    private TextView text(String value, int size) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(Color.rgb(35,35,35));
        t.setPadding(dp(8), dp(6), dp(8), dp(6)); return t;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private void addLabel(String s) { root.addView(text(s, 14)); }
    private Spinner spinner(String[] items) {
        Spinner s = new Spinner(this); ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); s.setAdapter(a); root.addView(s); return s;
    }
    private Button button(String label) { Button b = new Button(this); b.setText(label); root.addView(b, new LinearLayout.LayoutParams(-1, -2)); return b; }

    private void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16),dp(12),dp(16),dp(12)); root.setBackgroundColor(Color.rgb(244,247,244));
        android.widget.ScrollView scroll = new android.widget.ScrollView(this); scroll.addView(root); setContentView(scroll);
        TextView title = text("Fake Error Lab", 25); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setTextColor(Color.rgb(30,110,65)); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView warning = text("MÔ PHỎNG GIAO DIỆN — không phải lỗi Android thật, không treo máy.", 13); warning.setGravity(Gravity.CENTER); root.addView(warning);
        countdown = text("Đếm ngược: 10 giây", 18); countdown.setGravity(Gravity.CENTER); root.addView(countdown);
        addLabel("Loại hộp thoại:"); typeSpinner = spinner(types);
        addLabel("Màu giao diện:"); colorSpinner = spinner(colors);
        addLabel("Font chữ:"); fontSpinner = spinner(fonts);
        addLabel("Độ dài nội dung:"); lengthSpinner = spinner(lengths);
        addLabel("Thời gian đếm ngược (giây):");
        timerBar = new SeekBar(this); timerBar.setMax(30); timerBar.setProgress(10); root.addView(timerBar);
        status = text("Sẵn sàng. Hết giờ sẽ hiện hộp thoại giả lập.", 13); root.addView(status);
        preview = text("Xem trước hộp thoại…", 16); preview.setPadding(dp(14),dp(14),dp(14),dp(14)); root.addView(preview);
        Button restart = button("BẮT ĐẦU / ĐẶT LẠI ĐẾM NGƯỢC");
        restart.setOnClickListener(v -> { dialogShown=false; startTimer(Math.max(1,timerBar.getProgress())); });
        Button showNow = button("HIỆN LỖI GIẢ NGAY"); showNow.setOnClickListener(v -> showFakeDialog());
        Button exit = button("THOÁT ỨNG DỤNG"); exit.setOnClickListener(v -> { if (timer != null) timer.cancel(); finish(); });
        android.widget.AdapterView.OnItemSelectedListener listener = new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { updatePreview(); }
            public void onNothingSelected(android.widget.AdapterView<?> p) { }
        };
        typeSpinner.setOnItemSelectedListener(listener); colorSpinner.setOnItemSelectedListener(listener); fontSpinner.setOnItemSelectedListener(listener); lengthSpinner.setOnItemSelectedListener(listener);
    }

    private int selectedColor() {
        switch (colorSpinner.getSelectedItemPosition()) {
            case 1: return Color.rgb(38,38,38); case 2: return Color.rgb(218,244,224); case 3: return Color.rgb(255,246,195);
            case 4: return Color.rgb(255,222,222); case 5: return Color.rgb(220,235,255); default: return Color.WHITE;
        }
    }
    private Typeface selectedTypeface() {
        switch(fontSpinner.getSelectedItemPosition()) { case 1: return Typeface.create("sans-serif",Typeface.NORMAL); case 2: return Typeface.SERIF; case 3: return Typeface.MONOSPACE; default: return Typeface.DEFAULT; }
    }
    private String message() {
        String m;
        switch(typeSpinner.getSelectedItemPosition()) {
            case 0: m="Ứng dụng đang gặp sự cố và cần đóng."; break;
            case 1: m="Ứng dụng không phản hồi. Bạn có muốn chờ hay đóng ứng dụng?"; break;
            case 2: m="Đã xảy ra lỗi không xác định. Vui lòng thử lại."; break;
            case 3: m="Không thể tải nội dung. Hãy kiểm tra kết nối rồi thử lại."; break;
            case 4: m="Không thể kết nối tới máy chủ. Vui lòng thử lại sau."; break;
            default: m="Đây là nội dung lỗi do bạn tạo trong Fake Error Lab."; break;
        }
        int len=lengthSpinner.getSelectedItemPosition();
        if (len==0) return m.length()>48 ? m.substring(0,45)+"…" : m;
        if (len==2) return m+"\n\nMã lỗi: FE-104\nThời gian: vừa xong\nĐây chỉ là bản mô phỏng giao diện.";
        return m;
    }
    private void updatePreview() {
        if (preview==null || typeSpinner==null) return;
        preview.setText("XEM TRƯỚC\n\n"+message()+"\n\n[ Không ]       [ Có ]");
        preview.setBackgroundColor(selectedColor()); preview.setTypeface(selectedTypeface());
        preview.setTextColor(colorSpinner.getSelectedItemPosition()==1 ? Color.WHITE : Color.rgb(35,35,35));
        preview.setTextSize(16);
    }
    private void startTimer(int secs) {
        if (timer != null) timer.cancel(); seconds=secs; dialogShown=false;
        countdown.setText("Đếm ngược: "+seconds+" giây");
        timer = new CountDownTimer(seconds*1000L,1000L) {
            public void onTick(long left) { countdown.setText("Đếm ngược: "+((left+999)/1000)+" giây"); }
            public void onFinish() { countdown.setText("Đã hết giờ"); status.setText("Đã tạo/đã chọn lỗi giả lập."); showFakeDialog(); }
        }.start();
    }
    private void showFakeDialog() {
        if (isFinishing()) return;
        dialogShown=true;
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle(types[typeSpinner.getSelectedItemPosition()]); b.setMessage(message());
        b.setPositiveButton("Có", (d,w) -> { /* deliberately no action */ });
        b.setNegativeButton("Không", (d,w) -> { /* deliberately no action */ });
        if (typeSpinner.getSelectedItemPosition()==1) b.setNeutralButton("Chờ", (d,w) -> { /* deliberately no action */ });
        AlertDialog dialog=b.create(); dialog.setOnShowListener(d -> {
            int bg=selectedColor(); int fg=colorSpinner.getSelectedItemPosition()==1 ? Color.WHITE : Color.rgb(35,35,35);
            dialog.getWindow().setBackgroundDrawableResource(android.R.drawable.dialog_holo_light_frame);
            dialog.findViewById(android.R.id.message).setBackgroundColor(bg);
            ((TextView)dialog.findViewById(android.R.id.message)).setTextColor(fg);
            ((TextView)dialog.findViewById(android.R.id.message)).setTypeface(selectedTypeface());
            ((TextView)dialog.findViewById(android.R.id.message)).setTextSize(16);
        });
        dialog.show();
    }
    @Override public void onBackPressed() { if (timer!=null) timer.cancel(); super.onBackPressed(); }
}
