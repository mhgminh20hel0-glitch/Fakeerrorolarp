FAKE ERROR LAB — mã nguồn APK Android

Tính năng:
- Hộp thoại lỗi GIẢ trong chính ứng dụng (không phải hộp thoại hệ thống thật).
- Các kiểu: ứng dụng dừng, không phản hồi, lỗi chung, lỗi nội dung/kết nối, lỗi tùy chỉnh.
- Nút Có/Không/Chờ chỉ đóng hộp thoại, không thực hiện hành động nguy hiểm.
- Đếm ngược 1–30 giây; hết giờ hiện hộp thoại giả.
- Tùy chỉnh màu, font và độ dài nội dung.
- Không cố tình treo thiết bị hay làm crash ứng dụng.
- minSdk 15 (Android 4.0.3+), targetSdk 28; dự án hướng tới Android 4–12.

Cách tạo APK:
1. Mở thư mục FakeErrorLab bằng Android Studio.
2. Chờ Gradle Sync hoàn tất (cần Android SDK và kết nối tải plugin nếu chưa có).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Cài app/build/outputs/apk/debug/app-debug.apk lên điện thoại.

Lưu ý: môi trường tạo file hiện tại không có Android SDK/Gradle cài sẵn, nên gói này là mã nguồn dự án, chưa phải APK đã biên dịch.
